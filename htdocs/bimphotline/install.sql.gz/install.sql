--
-- Database: `GLE_TEST_BIMP6data`
--

-- --------------------------------------------------------

--
-- Table structure for table `llx_bh_equipment`
--

CREATE TABLE `llx_bh_equipment` (
  `id` int(11) NOT NULL,
  `id_product` int(10) UNSIGNED NOT NULL,
  `id_soc` int(10) UNSIGNED NOT NULL,
  `id_contrat` int(10) UNSIGNED NOT NULL,
  `serial` varchar(128) NOT NULL,
  `date_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_create` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_update` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `llx_bh_equipment`
--

INSERT INTO `llx_bh_equipment` (`id`, `id_product`, `id_soc`, `id_contrat`, `serial`, `date_create`, `date_update`, `user_create`, `user_update`) VALUES
(7, 3733, 81008, 0, '1234567', '2017-10-25 11:19:27', '2017-11-03 15:35:53', 1, 1),
(8, 6528, 171327, 1772, '1234567', '2017-10-25 11:19:27', '2017-11-01 21:29:58', 1, 1),
(9, 6506, 171279, 1, '778899', '2017-10-25 23:26:22', '2017-11-01 18:48:14', 1, 1),
(10, 6506, 80061, 1, '2233445566', '2017-10-30 15:06:38', '2017-11-01 18:23:51', 1, 1),
(12, 4350, 158341, 1, 'ascqd', '2017-11-01 18:49:29', '2017-11-01 18:49:29', 1, 0),
(13, 6528, 80061, 0, '123456879', '2017-11-02 17:16:57', '2017-11-02 17:16:57', 1, 0),
(14, 292, 142, 638, 'fffdfdfffd222223', '2017-11-03 15:34:29', '2017-11-04 16:25:59', 1, 1),
(15, 6528, 80061, 0, '123456879', '2017-11-07 13:37:46', '2017-11-07 13:37:46', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `llx_bh_inter`
--

CREATE TABLE `llx_bh_inter` (
  `id` int(11) NOT NULL,
  `id_ticket` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `tech_id_user` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `timer` int(10) UNSIGNED NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL DEFAULT '1',
  `description` text,
  `date_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_create` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `date_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_update` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `llx_bh_inter`
--

INSERT INTO `llx_bh_inter` (`id`, `id_ticket`, `tech_id_user`, `timer`, `priority`, `status`, `description`, `date_create`, `user_create`, `date_update`, `user_update`) VALUES
(11, 22, 1, 22, 1, 1, 'Test 2', '2017-11-08 15:58:29', 1, '2017-11-08 17:23:41', 1),
(12, 22, 1, 2, 1, 1, 'inter 2', '2017-11-08 16:13:32', 1, '2017-11-08 16:38:18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `llx_bh_note`
--

CREATE TABLE `llx_bh_note` (
  `id` int(11) NOT NULL,
  `id_ticket` int(10) UNSIGNED NOT NULL,
  `id_inter` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `visibility` int(11) NOT NULL,
  `content` text NOT NULL,
  `user_create` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `date_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_update` int(10) UNSIGNED DEFAULT NULL,
  `date_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `llx_bh_note`
--

INSERT INTO `llx_bh_note` (`id`, `id_ticket`, `id_inter`, `visibility`, `content`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES
(1, 22, 0, 3, 'TEST TEST', 1, '2017-11-08 14:10:31', 1, '2017-11-08 16:02:26'),
(2, 22, 0, 1, 'TEST 2 vvv', 1, '2017-11-08 14:12:53', 1, '2017-11-08 16:16:55');

-- --------------------------------------------------------

--
-- Table structure for table `llx_bh_ticket`
--

CREATE TABLE `llx_bh_ticket` (
  `id` int(11) NOT NULL,
  `id_contrat` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ticket_number` varchar(128) NOT NULL,
  `date_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_create` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `date_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_update` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `llx_bh_ticket`
--

INSERT INTO `llx_bh_ticket` (`id`, `id_contrat`, `ticket_number`, `date_create`, `user_create`, `date_update`, `user_update`) VALUES
(19, 666, 'BH171107090042', '2017-11-07 09:00:42', 1, '2017-11-07 09:00:42', 0),
(22, 1565, 'BH171107013627', '2017-11-07 13:36:27', 1, '2017-11-07 13:36:27', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `llx_bh_equipment`
--
ALTER TABLE `llx_bh_equipment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `llx_bh_inter`
--
ALTER TABLE `llx_bh_inter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `llx_bh_note`
--
ALTER TABLE `llx_bh_note`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `llx_bh_ticket`
--
ALTER TABLE `llx_bh_ticket`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `llx_bh_equipment`
--
ALTER TABLE `llx_bh_equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `llx_bh_inter`
--
ALTER TABLE `llx_bh_inter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `llx_bh_note`
--
ALTER TABLE `llx_bh_note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `llx_bh_ticket`
--
ALTER TABLE `llx_bh_ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
